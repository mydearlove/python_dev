#author wangzhaoyang
import   os
#print(os.getcwd())
#os.chdir("D:\python")
#print(os.getcwd())
#print(os.curdir)
#print(os.pardir)
#s.listdir("")
#print(os.stat(__file__))
#print(str(os.system("dir")).encode("utf-8"))
#os.path.abspath("C:\Users\Administrator\AppData\Local\Programs\Python\Python35")
os.path.split("")


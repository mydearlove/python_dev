#author wangzhaoyang
import   shutil,os
# f1 = open("os_test.py",encoding='utf-8')
# f2 = open("os_test123.py","w")
# shutil.copyfileobj(f1,f2)

#shutil.copytree("test","test1")
shutil.make_archive("wwwwww","gztar","D:\python\day5")
#print(os.getcwd())